#!/bin/sh

rm -rf /opt/otelcol
