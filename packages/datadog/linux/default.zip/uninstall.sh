#!/bin/sh

rm -rf /opt/datadog
